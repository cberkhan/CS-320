package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import service.Contact;
import service.ContactService;

class ContactServiceTest {

	@Test
	void testNewContact() {
		ContactService service = new ContactService();
		service.newContact("11111", "James", "Ham", "5556667777", "362 Goldenrod Ln");
		
        Contact contact = service.getContactList().get(0);
        assertEquals("11111", contact.getID());
        assertEquals("James", contact.getFirstName());
        assertEquals("Ham", contact.getLastName());
        assertEquals("5556667777", contact.getPhoneNumber());
        assertEquals("362 Goldenrod Ln", contact.getAddress());
	}
	
}
