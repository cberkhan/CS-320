package test;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

import service.TaskService;

class TaskServiceTest {
	

	@Test
	void testAddTask() {
		TaskService service = new TaskService();
		service.addTask("563247", "March", "HappyBirthday");
		service.displayTask();
	}
	
	@Test
	void testDeleteTask() {
		TaskService service = new TaskService();
		service.addTask("563247", "March", "HappyBirthday");
		service.deleteTask("563247");		
	}
	
	@Test
	void testUpdateTaskName() {
		TaskService service = new TaskService();
		service.addTask("563247", "March", "HappyBirthday");
		service.updateTaskName("April", "563247");
	}

}
