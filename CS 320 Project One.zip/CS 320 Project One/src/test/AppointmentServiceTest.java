package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import service.AppointmentService;

class AppointmentServiceTest {

	@Test
	void testAddAppointment() {
		AppointmentService service = new AppointmentService();
		service.addAppointment("563247", (new Date()), "HappyBirthday");
		service.displayAppointment();
	}
	
	@Test
	void testDeleteAppointment() {
		AppointmentService service = new AppointmentService();
		service.addAppointment("563247", (new Date()), "HappyBirthday");
		service.deleteAppointment("563247");
	}
	
}
