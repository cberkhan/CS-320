package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import service.Task;

class TaskTest {

	@Test
	void testTask() {
		Task task = new Task("41567", "Alex", "ABCDEFG");
		assertTrue(task.getID().equals("41567"));
		assertTrue(task.getName().equals("Alex"));
		assertTrue(task.getDescription().equals("ABCDEFG"));
	}
	
	@Test
	void testNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("42578", "HamburgerManSandwhichTunaFish", "ABCDE");
		});
	}
	
	@Test
	void testIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("4257898563423", "Hamburger", "ABCDE");
		});
	}
	
	@Test
	void testDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("42578", "Hamburger", "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ");
		});
	}
	
	@Test
	void testNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("42578", null, "ABCDE");
		});
	}
	
	@Test
	void testIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "Hamburger", "ABCDE");
		});
	}
	
	@Test
	void testDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("42578", "TunaFish", null);
		});
	}

}
