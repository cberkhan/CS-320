package test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import service.Appointment;


class AppointmentTest {

	@Test
	void testAppointment() {
		Appointment appointment = new Appointment("23654",(new Date()), "ABCDEFG");
		assertTrue(appointment.getID().equals("23654"));
		assertTrue(appointment.getDate().equals(new Date()));
		assertTrue(appointment.getDescription().equals("ABCDEFG"));
	}
	
	
	@Test
	void testIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("425789855663423", (new Date()), "ABCDE");
		});
	}
	
	@Test
	void testDescriptionTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("42578", (new Date()), "ABCDEFGHIJKLMNOPQRSTUVWXYZABCDEFGHIJKLMNOPQRSTUVWXYZ");
		});
	}
	
	@Test
	void testDateNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("42578", null, "ABCDE");
		});
	}
	
	@Test
	void testIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment(null, (new Date()), "ABCDE");
		});
	}
	
	@Test
	void testDescriptionNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment("42578", (new Date()), null);
		});
	}


}
