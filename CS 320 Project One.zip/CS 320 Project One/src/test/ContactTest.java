package test;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import service.Contact;

class ContactTest {

	@Test
	void testFirstAndLastName() {
		Contact contact = new Contact("789456", "Michael", "Scott", "7778889999", "184 May St");
		contact.setFirstName("Michael");
		contact.setLastName("Scott");
		assertTrue(contact.getFirstName().equals("Michael"));
		assertTrue(contact.getLastName().equals("Scott"));
	}
	
	@Test
	void testGetters() {
		Contact contact = new Contact("564897", "Sam", "Smith", "2223334444", "256 Broad St");
		
		assertEquals("564897", contact.getID());
		assertEquals("Sam", contact.getFirstName());
		assertEquals("Smith", contact.getLastName());
		assertEquals("2223334444", contact.getPhoneNumber());
		assertEquals("256 Broad St", contact.getAddress());
	}
	
	@Test
	void testSetters() {
		Contact contact = new Contact("421365", "Mark", "Alex", "1115556666", "479 Main St");
		
		contact.setID("421365");
		contact.setFirstName("Mark");
		contact.setLastName("Alex");
		contact.setPhoneNumber("1115556666");
		contact.setAddress("479 Main St");
		
		assertEquals("421365", contact.getID());
		assertEquals("Mark", contact.getFirstName());
		assertEquals("Alex", contact.getLastName());
		assertEquals("1115556666", contact.getPhoneNumber());
		assertEquals("479 Main St", contact.getAddress());
	}
	
	@Test
	void testContactNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, null, null, null, null);
		});
		
	}

}
