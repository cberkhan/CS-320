package service;
import java.util.ArrayList;
import java.util.List;

public class ContactService {

	public List<Contact> contactList = new ArrayList<Contact>();
	
	public void newContact(String ID, String firstName, String lastName, String phoneNumber, String address) {
		
		for (int i = 0; i < contactList.size(); i++) {
			if (ID.equals(contactList.get(i).getID())) {
				throw new IllegalArgumentException("Existing Contact");
			}
		}
		
		contactList.add(new Contact(ID, firstName, lastName, phoneNumber, address)); 
			
	}
	
	public List<Contact> getContactList() {
		return contactList;
	}
	
	public void deleteContact(String ID) {
		
		for (int i = 0; i < contactList.size();) {
			if (ID.equals(contactList.get(i).getID())) {
				
				contactList.remove(i);
				return;
			}
			
			else {
				throw new IllegalArgumentException("Contact does not exist");
			}
		}
	}
	
	
}
