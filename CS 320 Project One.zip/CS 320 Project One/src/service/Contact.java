package service;

public class Contact {

	private String ID;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;


	public void setID(String ID) {
		if (ID == null || ID.length() > 10) {
			throw new IllegalArgumentException("Invalid ID Entered");
		}
		else {
			this.ID = ID;
		}
	}
	
	public void setFirstName(String firstName) {
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name Entered");
		}
		else {
			this.firstName = firstName;
		}
	}
	
	public void setLastName(String lastName) {
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name Entered");
		}
		else {
			this.lastName = lastName;
		}
	}
	
	public void setPhoneNumber(String phoneNumber) {
		if (phoneNumber == null || phoneNumber.length() != 10) {
			throw new IllegalArgumentException("Invalid Phone Number Entered");
		}
		else {
			this.phoneNumber = phoneNumber;
		}
	}
	
	public void setAddress(String address) {
		if (address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid Address Entered");
		}
		else {
			this.address = address;
		}
	}
	
	public String getID() {
		return ID;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public String getAddress() {
		return address;
	}
	
	public Contact (String contactID, String FName, String LName, String phoneNum, String Address) {
		
		setID(contactID);
		setFirstName(FName);
		setLastName(LName);
		setPhoneNumber(phoneNum);
		setAddress(Address);
	}
	
}
