package service;

import java.util.ArrayList;

public class TaskService {
	
	public ArrayList<Task> taskList = new ArrayList<Task>();
	
	public void addTask(String ID, String name, String description) {
		
		Task task = new Task(ID, name, description);
		taskList.add(task);
	}
	
	public void deleteTask(String ID) {
		for (int counter = 0; counter < taskList.size(); counter++) {
			if (taskList.get(counter).getID().equals(ID)) {
				taskList.remove(counter);
				break;
			}
		}
	}
	
	public void updateTaskName(String updateName, String ID) {
		for(int counter = 0; counter < taskList.size(); counter++) {
			if (taskList.get(counter).getID().equals(ID)) {
				taskList.get(counter).setName(updateName);
				break;
			}
		}
	}
	
	public void updateTaskDescription(String updateDescription, String ID) {
		for (int counter = 0; counter < taskList.size(); counter++) {
			if (taskList.get(counter).getID().equals(ID)) {
				taskList.get(counter).setDescription(updateDescription);
				break;
			}
		}
	}
	
	public void displayTask() {
		for (int counter = 0; counter < taskList.size(); counter++) {
			System.out.println("\t Task ID: " + taskList.get(counter).getID());
			System.out.println("\t Task Name: " + taskList.get(counter).getName());
			System.out.println("\t Task Description: " + taskList.get(counter).getDescription());
		}
	}
	

}
