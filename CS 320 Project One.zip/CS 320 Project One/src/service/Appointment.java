package service;

import java.util.Date;

public class Appointment {
	
	private String ID;
	private Date date;
	private String description;
	
	public Appointment (String ID, Date date, String description) {
		if (ID == null || ID.length() > 10) {
			throw new IllegalArgumentException("Invalid ID");
		}
		
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Invalid Appointment Date");
		}
		
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		
		this.ID = ID;
		this.date = date;
		this.description = description;
		
	}
	
	public String getID() {
		return ID;
	}
	
	public Date getDate() {
		return date;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDate(Date date) {
		if (date == null || date.before(new Date())) {
			throw new IllegalArgumentException("Invalid Date");
		}
		else {
			this.date = date;
		}
	}
	
	public void setDescription(String description) {
		if (description == null || description.length() > 50) {
			throw new IllegalArgumentException("Invalid Description");
		}
		else {
			this.description = description;
		}
	}
	
		
}

