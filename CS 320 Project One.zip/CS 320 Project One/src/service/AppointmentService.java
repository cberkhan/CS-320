package service;

import java.util.ArrayList;
import java.util.Date;


public class AppointmentService {
	
	public ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();
	
	public void addAppointment(String ID, Date date, String description) {
		
		Appointment appointment = new Appointment(ID, date, description);
		appointmentList.add(appointment);
	}
	
	public void deleteAppointment(String ID) {
		for (int counter = 0; counter < appointmentList.size(); counter++) {
			if (appointmentList.get(counter).getID().equals(ID)) {
				appointmentList.remove(counter);
				break;
			}
		}
	}
	
	public void updateAppointmentDate(Date updatedDate, String ID) {
		for(int counter = 0; counter < appointmentList.size(); counter++) {
			if (appointmentList.get(counter).getID().equals(ID)) {
				appointmentList.get(counter).setDate(updatedDate);
				break;
			}
		}
	}
	
	public void updateAppointmentDescription(String updateDescription, String ID) {
		for (int counter = 0; counter < appointmentList.size(); counter++) {
			if (appointmentList.get(counter).getID().equals(ID)) {
				appointmentList.get(counter).setDescription(updateDescription);
				break;
			}
		}
	}
	
	public void displayAppointment() {
		for (int counter = 0; counter < appointmentList.size(); counter++) {
			System.out.println("\t Appointment ID: " + appointmentList.get(counter).getID());
			System.out.println("\t Appointment Name: " + appointmentList.get(counter).getDate());
			System.out.println("\t Appointment Description: " + appointmentList.get(counter).getDescription());
		}
	}
	


}
